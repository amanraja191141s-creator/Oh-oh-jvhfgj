# Sable Calculator v100.0 — QA report

## Release scope
A new Sable-branded application shell and visual system replaces the previous SA Calculator navy/blue UI. The new product uses a warm-paper / graphite / persimmon visual language and Desk / Explore / Activity / Profile navigation. Saved tools now live inside Explore. Light, Dark and Follow device modes are functional, with six new accent palettes and a v3 migration away from the old forced-blue theme.

The previous calculator/domain engines and currency refresh/provider logic remain the compatibility core. Six new standalone calculator engines have been added in `assets/js/sable-calculators.js`: Bill Split, Compound Growth, Markup & Margin, Ratio Split, Quick Statistics and Time Span.

## Automated verification completed
- 97/97 Node tests passed, including new Android workflow and native system-bar regression checks.
- 25/25 JavaScript source, test and build files passed `node --check`.
- CSS parser: 0 parse errors in the new canonical stylesheet.
- HTML parsed successfully; no duplicate IDs.
- 23 tool cards found and each new destination has a dedicated screen.
- Six accent palettes, three appearance modes and OLED styling are wired into the new theme token system.
- Android web bundle generated successfully; 14 required source assets verified and 27 output files produced.
- New calculator module is included in the generated bundle and service-worker precache.
- GitHub Actions workflow parsed with a YAML 1.2 parser; required triggers/jobs were inspected; repository workflow and standalone YAML are byte-identical. A hosted GitHub Actions run has not yet been performed.
- Package, HTML, manifest and service-worker cache identity are synchronized to `2.00.0-v100.0`.
- New Sable icon artwork is present in the Android launcher icon set.
- Android build workflow now explicitly provisions Node 22, Java 17 and Android SDK Platform 35 / Build Tools 35.0.0.
- Android native fallback window background and status/navigation icon contrast now match the warm-paper theme (dark system icons on light surfaces).
- Workflow verifies the project root, Capacitor identity, all required source assets, tool count, regression suite, web bundle and non-empty APK artifact before upload.
- Workflow supports `main` and `master`, manual dispatch and `v*` tags.
- Standalone YAML is intended to be copied to `.github/workflows/main.yml`; GitHub does not load workflow files from the repository root.
- The final source ZIP is re-extracted and retested before delivery.

## Desk research
Reviewed public product information for 23 calculator products, including Google Calculator, Samsung Calculator, ClevCalc, HiPER, RealCalc, Desmos Scientific, Desmos Graphing, GeoGebra, Wolfram|Alpha, Calculator Plus, All-In-One Calculator, CalcKit, CalcKit.io, PCalc, Calzy, Soulver, Calca, MyScript Calculator 2, Mathlab, Calculator++, CALCU, Fossify Calculator and NCalc.

This was public-page desk research, not identical-device hands-on benchmarking of every product. See `RESEARCH-23-CALCULATOR-APPS-v100.0.md` for the feature signals, synthesis and source links.

## Not yet verified
- A live GitHub Actions run and actual Android APK artifact (the hosted runner is required to validate SDK/Gradle download and compilation end-to-end).
- Installation and use on a physical Android handset.
- Visual screenshot review across multiple Android OEMs, display densities and font scaling.
- TalkBack/manual accessibility audit.
- Sustained frame-time, memory and thermal/performance benchmarking.
- Live currency provider connectivity with the user's production API credentials.

A passing automated suite is not proof of zero defects or zero lag on every handset. These final claims require physical-device and live-service testing.
