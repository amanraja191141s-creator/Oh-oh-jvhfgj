# Sable Calculator v100.0

Sable is an independent calculation studio with a new warm-paper / graphite / persimmon visual identity.

## What is new in v100.0
- Replaced the prior blue/navy skin with a new warm-paper design system and a matching dark palette.
- Replaced the former five-item navigation presentation with Desk, Explore, Activity and Profile.
- Moved Saved tools into the Explore library rather than keeping a separate primary tab.
- Rebuilt the calculator display, keypad, tool directory, form fields, result cards, settings and history surfaces.
- Rebranded the app shell, manifest, service-worker cache and Android launcher artwork.
- Replaced the old stylesheet with one new canonical `assets/css/app.css`.

## App structure
- **Desk:** everyday calculator with live expression and result display.
- **Explore:** searchable tool library grouped by Convert, Finance, Math and Daily.
- **Activity:** calculation history and reuse actions.
- **Profile:** appearance, input, privacy and application preferences.
- **Saved tools:** shortcut collection reachable from Explore.

## Calculation modules
Basic and scientific calculation, currency and unit conversion, discount, percentage, sales tax, body metrics, date, fuel cost, fuel efficiency, grade average, hexadecimal, loan, savings, tip, unit price, world time, bill split, compound growth, markup & margin, ratio split, quick statistics and time span.

The existing calculation/domain engines and currency provider logic are retained as the functional core. The visual system, branding, shell navigation and CSS are replaced. This release does not claim every mathematical/provider engine has been rewritten from scratch.

## Build locally
Requirements: Node.js 22, Java 17, Android SDK Platform 35 and Build Tools 35.0.0 for the included Capacitor 7 Android build.

```bash
npm install
npm test
npm run build:web
npx cap add android
npm run android:brand
npm run android:apk
```

If the Android platform already exists, skip `npx cap add android`.

## GitHub Actions
Upload the **contents** of the extracted `Sable-Calculator-v100.0` folder to the repository root (do not upload the outer folder as an extra nesting level). The workflow file must be at exactly `.github/workflows/main.yml` — not in the repository root and not inside a second nested `.github` folder. GitHub → Actions → **Sable Calculator v100.0 — Android Release** → Run workflow. The workflow sets up Node 22, Java 17 and Android SDK 35, verifies the source identity and required files, installs dependencies, runs tests, prepares the web bundle, generates the Android project, applies native branding/system-bar insets, builds a debug APK and uploads it as an artifact. It supports `main` and `master` branches plus manual dispatch and `v*` tags.

## QA limits
Automated tests and static build checks do not replace a physical Android device test. Actual GitHub Actions APK generation, installation across OEM devices, TalkBack, font scaling and sustained performance benchmarking remain separate release checks.


## If GitHub says the workflow is missing
GitHub Actions only discovers workflow files inside `.github/workflows/`. In the repository, the final path must be `.github/workflows/main.yml`. Do not upload the standalone YAML to the repository root. The ZIP already contains the correct workflow at `.github/workflows/main.yml`; the separate YAML download is the same file for manual replacement. Upload the extracted project contents, preserving the hidden `.github` directory.
