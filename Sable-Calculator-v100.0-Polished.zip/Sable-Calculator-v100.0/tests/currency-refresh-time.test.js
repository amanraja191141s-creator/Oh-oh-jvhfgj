const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function createContext(store = {}) {
  const values = { ...store };
  const node = { textContent: '', attributes: {}, setAttribute(k, v) { this.attributes[k] = v; } };
  const context = {
    Date, Number, String, JSON, Intl, Object,
    STATE: { currencyLastRefreshAt: null, currencyLastSuccessfulRefreshAt: null, currencyUpdatedAt: null },
    CURRENCY_REFRESH_META_KEY: 'sa_currency_refresh_meta_v1',
    localStorage: { getItem: k => values[k] ?? null, setItem: (k, v) => { values[k] = v; } },
    document: { getElementById: id => id === 'cur-refresh-time' ? node : null },
  };
  vm.createContext(context);
  vm.runInContext(`${extract('formatCurrencyRefreshTimestamp')};${extract('renderCurrencyRefreshTimes')};${extract('loadCurrencyRefreshMeta')};${extract('saveCurrencyRefreshMeta')};`, context);
  context.values = values; context.node = node;
  return context;
}

test('refresh timestamps display both latest completed check and last successful rate update', () => {
  const now = Date.now();
  const c = createContext({ sa_currency_refresh_meta_v1: JSON.stringify({ lastRefreshAt: now, lastSuccessfulRefreshAt: now - 60000 }) });
  assert.equal(c.loadCurrencyRefreshMeta(), true);
  assert.match(c.node.textContent, /^Last checked: /);
  assert.match(c.node.textContent, / · Rates last updated: /);
  assert.match(c.node.attributes['aria-label'], /device's local time/);
  assert.notEqual(c.node.textContent, 'Last checked: Not yet · Rates last updated: Not yet');
});

test('failed refresh metadata can advance last checked without erasing last successful update', () => {
  const c = createContext();
  c.STATE.currencyLastRefreshAt = Date.now();
  c.STATE.currencyLastSuccessfulRefreshAt = Date.now() - 86400000;
  c.saveCurrencyRefreshMeta();
  const saved = JSON.parse(c.values.sa_currency_refresh_meta_v1);
  assert.equal(saved.lastRefreshAt, c.STATE.currencyLastRefreshAt);
  assert.equal(saved.lastSuccessfulRefreshAt, c.STATE.currencyLastSuccessfulRefreshAt);
  assert.match(c.node.textContent, /Last checked:/);
  assert.match(c.node.textContent, /Rates last updated:/);
});

test('missing refresh metadata migrates last successful cached update timestamp', () => {
  const c = createContext();
  c.STATE.currencyUpdatedAt = Date.now() - 120000;
  assert.equal(c.loadCurrencyRefreshMeta(), false);
  assert.equal(c.STATE.currencyLastRefreshAt, c.STATE.currencyUpdatedAt);
  assert.equal(c.STATE.currencyLastSuccessfulRefreshAt, c.STATE.currencyUpdatedAt);
});

test('invalid or future refresh timestamps are never displayed as valid times', () => {
  const c = createContext({ sa_currency_refresh_meta_v1: JSON.stringify({ lastRefreshAt: Date.now() + 86400000, lastSuccessfulRefreshAt: 'invalid' }) });
  c.loadCurrencyRefreshMeta();
  assert.equal(c.STATE.currencyLastRefreshAt, null);
  assert.equal(c.STATE.currencyLastSuccessfulRefreshAt, null);
  assert.equal(c.node.textContent, 'Last checked: Not yet · Rates last updated: Not yet');
});
