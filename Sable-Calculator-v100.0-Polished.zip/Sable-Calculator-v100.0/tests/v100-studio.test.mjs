import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html=fs.readFileSync('index.html','utf8');
const app=fs.readFileSync('assets/js/app.js','utf8');
const addon=fs.readFileSync('assets/js/sable-calculators.js','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));

test('Sable v100 identity is synchronized',()=>{
 assert.equal(pkg.name,'sable-calculator');
 assert.equal(pkg.version,'2.00.0-v100.0');
 assert.match(html,/Sable/); assert.match(html,/2\.00\.0-v100\.0/);
 assert.equal(manifest.name,'Sable Calculator');
 assert.match(fs.readFileSync('service-worker.js','utf8'),/sable-calculator-v100-0-original-studio-v1000/);
});

test('new visual language replaces the former blue/navy theme',()=>{
 assert.match(css,/--paper:#f4f1e9/);
 assert.match(css,/--accent:#e45b3d/);
 assert.match(css,/--key:#292d29/);
 assert.doesNotMatch(css,/#1976d2|#4d5cff|#0088cc/);
 assert.match(html,/sable-brand-mark/);
 assert.match(html,/YOUR CALCULATION DESK/);
});

test('new primary navigation exposes Desk, Explore, Activity and Profile only',()=>{
 const nav=html.slice(html.indexOf('id="bottom-navigation"'),html.indexOf('</nav>',html.indexOf('id="bottom-navigation"')));
 const visible=[...nav.matchAll(/data-bottom-nav="(calc|tools|history|settings)"/g)].map(m=>m[1]);
 assert.deepEqual(visible,['calc','tools','history','settings']);
 assert.match(nav,/>Desk</); assert.match(nav,/>Explore</); assert.match(nav,/>Activity</); assert.match(nav,/>Profile</);
 assert.match(nav,/sable-saved-compat/);
});

test('theme preferences are real and the former forced-blue lock is removed',()=>{
 assert.match(app,/function applySettingTheme\(val\) \{\s*if \(!\['light', 'dark', 'system'\]\.includes\(val\)\) val = 'light'/);
 assert.match(app,/theme: 'light'/);
 assert.match(app,/accentColor: '#e45b3d'/);
 assert.doesNotMatch(app,/val = 'dark'|color = '#4d5cff'|#1976d2|#087fff/);
 assert.equal((html.match(/class="theme-option"/g)||[]).length,6);
 assert.match(css,/html\.oled-theme,body\.oled-theme/);
});

test('Saved tools are integrated into Explore and can return to the library',()=>{
 assert.match(html,/id="btn-open-saved-tools"/);
 assert.match(html,/id="btn-favorites-back"/);
 assert.match(app,/btn-open-saved-tools/);
 assert.match(app,/btn-favorites-back/);
 assert.match(app,/switchScreen\('favorites'\)/);
});

test('all existing calculator destinations remain present and reachable',()=>{
 const screens=[...html.matchAll(/id="screen-([^"]+)"/g)].map(m=>m[1]);
 for(const s of ['calc','scientific','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','billsplit','compoundgrowth','markupmargin','ratiosplit','quickstats','timespan','tools','favorites','settings']) assert.ok(screens.includes(s),`missing ${s}`);
 assert.equal((html.match(/data-tool-screen="/g)||[]).length,23);
 for(const id of ['billsplit','compoundgrowth','markupmargin','ratiosplit','quickstats','timespan']) assert.match(app,new RegExp(`id: '${id}'`));
});

test('new style system covers all primary surfaces, forms, tools, settings and accessibility',()=>{
 for(const token of ['.calc-display','.main-keypad','.premium-tool-card','.settings-row','.reference-field','.scientific-display','#history-modal','.sable-navigation','prefers-reduced-motion:reduce']) assert.ok(css.includes(token),`missing style ${token}`);
 assert.match(css,/@media\(max-width:360px\)/);
 assert.match(css,/focus-visible/);
});

test('calculation engines and currency refresh systems remain wired to their existing UI controls',()=>{
 for(const token of ['formatCurrencyRefreshTimestamp','renderCurrencyRefreshTimes','initBottomNavigation','function switchScreen','calcLoan','calcDiscount']) assert.ok(app.includes(token),`missing engine ${token}`);
 for(const token of ['billSplit','compoundGrowth','markupMargin','ratioSplit','quickStats','timeSpan']) assert.ok(addon.includes(token),`missing new calculator ${token}`);
 assert.match(html,/id="cur-refresh-time"/);
 assert.match(html,/id="cur-rate-status"/);
});

test('Android workflow builds only the Sable v100 release and uploads APK',()=>{
 assert.match(workflow,/2\.00\.0-v100\.0/);
 assert.match(workflow,/npm test/);
 assert.match(workflow,/npm run build:web/);
 assert.match(workflow,/npx cap add android/);
 assert.match(workflow,/sable-calculators\.js/);
 assert.match(workflow,/npm run android:brand/);
 assert.match(workflow,/npm run android:apk/);
 assert.match(workflow,/actions\/upload-artifact@v4/);
 assert.match(workflow,/android-actions\/setup-android@v3/);
 assert.match(workflow,/java-version: '17'/);
 assert.match(workflow,/platforms;android-35/);
 assert.match(workflow,/npm ls --depth=0/);
 assert.match(workflow,/test -s \"\$APK\"/);
 assert.match(workflow,/branches:\n      - main\n      - master/);
});

test('Android native fallback surface and system-bar icons match the warm-paper UI',()=>{
 const native=fs.readFileSync('scripts/patch-android-native.mjs','utf8');
 assert.match(native,/Color\.rgb\(244, 241, 233\)/);
 assert.match(native,/setAppearanceLightStatusBars\(true\)/);
 assert.match(native,/setAppearanceLightNavigationBars\(true\)/);
 assert.doesNotMatch(native,/Color\.rgb\(2, 7, 19\)|setAppearanceLightStatusBars\(false\)/);
});
